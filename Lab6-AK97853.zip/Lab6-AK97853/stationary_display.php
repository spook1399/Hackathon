<html>
<body style="background-color:lemonchiffon;">
<?php 
	$code = $_GET["scode"];
	$name = $_GET["sname"];
	$type = $_GET["stype"]; 
	$brand = $_GET["sbrand"];
	$price = $_GET["sprice"]; 
	$quantity = $_GET["squantity"];
	$date = $_GET["datereceived"];
	

	echo "<hr><center><img src='qamar_stationary.jpg' height='300' width='600' alt='logo'></center><hr>";
	echo "<h1>Stationary Display Details</h1>";
	echo "<br>";
	echo "Stationary Code : <b>$code</b>";
	echo "<br>";
	echo "Stationary Name : <b>$name</b>";
	echo "<br>";
	echo "Stationary Type : <b>$type</b>";
	echo "<br>";
	echo "Stationary Brand : <b>$brand</b>";
	echo "<br>";
	echo "Stationary Price : RM<b>$price</b>";
	echo "<br>";
	echo "Stationary Quantity : <b>$quantity</b>";
	echo "<br>";
	echo "Date Received : <b>$date</b>";
?>
</body>
</html>
