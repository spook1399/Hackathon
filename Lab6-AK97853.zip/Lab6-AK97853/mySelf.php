<!DOCTYPE HTML>
<html>

<?php
	
	$namaPena = $_POST["nickName"];
	$DOB = $_POST["dob"];
	$favcol = $_POST["favcolor"];
	$myHobby = $_POST["hobby"];
	
	//calculate age
	$today = date('Y-m-d');
	$Age = date_diff(date_create($DOB), date_create($today));
	
	//change date format to DD-MM-YYYY
	$DOBNew = new DateTime($DOB);
	
?>

<body>

	<h2>About My Self</h2>
	
	<table border="1" width="25%">
	<tr>
		<td> Nick Name : </td>
		<th> <?php echo $namaPena; ?></th>
	</tr>
	<tr>
		<td> D.O.B : </td>
		<th> <?php echo $DOBNew->format('d-m-y'); ?></th>
	</tr>
	<tr>
		<td> My Age : </td>
		<th> <?php echo $Age->format('%y'); ?> years old </th>
	</tr>
	<tr>
		<td> My Favourite Colour : </td>
		<th> <?php echo "<b style='color:$favcol;'>this COLOUR</b>"; ?></th>
	</tr>
	<tr>
		<td> My Hobby : </td>
		<th> <?php foreach($myHobby as $hobbyList){
				echo "$hobbyList <br>";
		} ?>
		</th>
	</tr>
	</table>
</body>
</html>